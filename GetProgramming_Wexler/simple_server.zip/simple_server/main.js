const http = require('http');
const app = http.createServer();
app.on('request', (req, res) => {
  console.log(req.method);
  console.log(req.url);
  console.log(req.headers);
  res.writeHead(200, {"Content-Type": "text/html"});
  res.write("<h1> Hello, Boca2!</h1>");
  res.end();
});

app.listen(3000);
console.log("listening on port 3000");
console.log("tracking requests");
