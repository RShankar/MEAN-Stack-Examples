"use strict";
const canadianDollar = 0.8;// Conversion factor as of 10/2017
function roundTwo(amount) {
  let result = Math.round(amount * 100)/100;
  //console.log (result);
  return result;
}

exports.canadianToUS = (canadian) => {
  roundTwo(canadian * canadianDollar);
};

exports.USToCanadian = (us) => {
  roundTwo(us/canadianDollar);
};
