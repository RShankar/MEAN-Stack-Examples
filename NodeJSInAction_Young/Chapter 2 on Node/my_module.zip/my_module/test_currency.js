"use strict";
const currency = require('./currency');

let canadian = 50;
let us = 30;
let ev = currency.canadianToUS(canadian);
console.log (ev);
console.log (canadian + " canadian dollars" + " equals: " +  ev + " US dollars");
let ev1 = currency.USToCanadian(us);
console.log(ev1);
