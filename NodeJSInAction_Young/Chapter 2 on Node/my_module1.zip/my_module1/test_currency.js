"use strict";
const Currency = require('./currency');

let canadian = 50;
let us = 30;
let canadianDollar = 0.8;
const currency = new Currency (canadianDollar);
let ev = currency.canadianToUS(canadian);
console.log (ev);
console.log (canadian + " canadian dollars" + " equals: " +  ev + " US dollars");
let ev1 = currency.USToCanadian(us);
console.log(ev1);
