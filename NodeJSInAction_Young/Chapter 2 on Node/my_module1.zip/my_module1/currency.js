"use strict";
//const canadianDollar = 0.8;// Conversion factor as of 10/2017
class Currency {
  constructor (canadianDollar) {
    this.canadianDollar = canadianDollar;
  }

  roundTwo(amount) {
    let result = Math.round(amount * 100)/100;
    //console.log (result);
    return result;
  }

 canadianToUS(canadian) {
   return this.roundTwo(canadian * this. canadianDollar);
 }

 USToCanadian(us) {
   return this.roundTwo(us/ this.canadianDollar);
 }

}

module.exports = Currency;
